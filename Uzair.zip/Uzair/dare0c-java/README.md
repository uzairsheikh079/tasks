# Assignment 2 - Reverse a file with Java

Change the source file Reverser.java between the designated comment
lines such that it outputs “OK”.  __Do__ __not__ __use__ any standard
library classes in your solution!

Commit your changes and prepare a patch:

        git format-patch origin/master

Send the patch file to developer-assessment@bayard-consulting.com
