# Assignment 3 - Process XML with Java

Compile the source code in this directory and run the Unit Tests with Apache Maven,
e.g. using the command ``mvn package``.
It will output a message similar to:

        Results :

        Failed tests:   tranformSample1(TransformerTest): expected:<[<document><item><name>B</name><score>0.5</score></item><item><name>A</name><score>0.8</score></item></document>]> but was:<[]>
          tranformSample2(TransformerTest): expected:<[<document><item><name>B</name><score>0.1</score></item><item><name>A</name><score>0.2</score></item><item><name>D</name><score>0.6</score></item><item><name>C</name><score>0.9</score></item></document>]> but was:<[]>

          Tests run: 2, Failures: 2, Errors: 0, Skipped: 0

Change the source file SortingTransformer.java between the designated comment
lines such that the Unit Tests succeed.

Commit your changes and prepare a patch:

        git format-patch origin/master

Send the patch file to developer-assessment@bayard-consulting.com
